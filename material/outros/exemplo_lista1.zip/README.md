## Exemplo para lista de exercícios

Compilação: `g++ teste_prof.cpp -o appTeste`

Execução: `./appTeste -d yes`

Saída esperada: deve falhar no exercício 0 (está errado de propósito!).

Para cada exercício, preencham a função dada no arquivo de exemplo do professor,
chamado `IgorMachadoCoelho.hpp`. Façam o próprio arquivo .hpp de vocês, com o 
nome completo, e SOMENTE ele será enviado na plataforma (nada mais!).

